# Snapin Admin (server bingkai)

Server kecil untuk Vercel: halaman admin untuk mengunggah bingkai Canva (PNG/WebP),
dan API yang dibaca aplikasi Snapin. Penyimpanan memakai Vercel Blob (tanpa Firebase).

## Isi
- `admin.html`  halaman admin, dibuka di `/admin`
- `api/image-frames.js`  daftar bingkai untuk aplikasi (publik)
- `api/img.js`  gambar bingkai (publik, dengan CORS)
- `api/admin.js`  simpan / daftar / hapus (butuh password admin)
- `api/frames.js`, `api/filters.js`  disiapkan untuk nanti, sekarang mengembalikan daftar kosong

## Pasang di Vercel
1. Upload isi project ini ke repo GitHub (boleh Private).
2. Di Vercel: Add New > Project > pilih repo > Deploy.
3. Di project Vercel: tab Storage > Create > Blob (public atau private, dua-duanya didukung), lalu hubungkan ke project ini.
   Vercel menambahkan `BLOB_STORE_ID` dan login OIDC otomatis (tidak ada lagi BLOB_READ_WRITE_TOKEN, itu normal).
4. Settings > Environment Variables: tambah `ADMIN_PASSWORD` (pilih password yang kuat).
5. Deployments > Redeploy (supaya variabel terbaca).
6. Buka `https://NAMA-PROJECT.vercel.app/admin`, masuk dengan password, lalu upload bingkai.

## Aturan bingkai
- Lubang foto: bagian transparan, atau satu warna polos (hijau, magenta, cyan, kuning).
- Maksimal 6 lubang. Bingkai tampil saat pengguna memilih jumlah foto yang sama dengan jumlah lubang.
- Urutan foto: atas ke bawah, kiri ke kanan.


---

## Update v2: rasio, animasi, kode redeem, QRIS

### Perbaikan hijau berbekas
Kunci warna sekarang mencari warna hijau SEBENARNYA di gambar (mis. 44,218,40, bukan hijau murni), menghapusnya
hanya di area yang tersambung ke lubang foto (hijau di desain, misalnya dinosaurus, tetap aman), lalu menetralkan
sisa hijau di tepi. **Bingkai lama yang sudah terlanjur diupload perlu diupload ulang** supaya memakai hasil baru.

### Di dashboard admin
- Upload bingkai: pilih **rasio** (1:1, 4:3 tegak/landscape, 16:9 tegak/landscape), **untuk Foto atau Video** (video = 1 lubang),
  tema, berbayar + **Harga QRIS**. Rasio ditebak otomatis dari bentuk lubang.
- GIF / WebP animasi / APNG boleh diupload (harus lubang transparan, bukan hijau polos; maks sekitar 3 MB).
- Tombol **Ubah** di tiap bingkai: ganti rasio, tema, nama, harga tanpa upload ulang.
- **Kode redeem**: untuk dijual manual lewat chat.
- **Toko QRIS**: nama toko, link bantuan, kunci fitur premium, **Paket** (beberapa bingkai/fitur satu harga), dan daftar **Penjualan**.

### Pembayaran QRIS (sama alurnya dengan GVSUPERZSTORE, tanpa login)
Variabel Vercel yang dibutuhkan (boleh sama dengan milik GVSUPERZSTORE):
- `PUNYAKIOS_API_KEY`, `PUNYAKIOS_API_SECRET`
- `ADMIN_PASSWORD` (sudah ada). Opsional `ORDER_SECRET` (kunci tanda tangan pesanan, default memakai ADMIN_PASSWORD)

Alur: aplikasi minta QRIS (`/api/qris` create) -> QR tampil di aplikasi (biaya QRIS ditanggung pembeli) -> aplikasi mengecek
status ke PunyaKios (`check`, hanya status resmi "paid" yang dipercaya, nominal dicek) -> server mengirim **token buka** yang
terikat ke ID perangkat -> bingkai terbuka dan tersimpan di HP (offline).
Tidak ada akun dan server tidak menyimpan pesanan: pesanan dibawa sebagai token bertanda tangan HMAC, jadi harga tidak bisa
diubah dari aplikasi. Pembayaran yang tertunda dicek ulang saat aplikasi dibuka.

Webhook `https://DOMAIN/api/qris-callback` opsional (PunyaKios hanya punya SATU URL webhook per akun; kalau akun yang sama dipakai
GVSUPERZSTORE, biarkan di sana, pembayaran Snapin tetap terkonfirmasi lewat pengecekan dari aplikasi).

Batas yang perlu kamu tahu:
- Catatan **Penjualan** terisi saat aplikasi pembeli mengonfirmasi. Data resmi ada di dashboard PunyaKios.
- Kunci fitur premium (Studio, video berbingkai) dijaga di sisi aplikasi; yang dijaga ketat di server hanyalah **gambar bingkai berbayar**.

---

## Update v4: deteksi bingkai lebih kuat, mendukung strip 1 sampai 6 foto
- Warna kunci diambil dari warna yang paling banyak dipakai di lubang (bukan rata-rata), jadi hijau di desain tidak menggeser warna kunci.
- Bagian dalam lubang dijamin transparan 100%; hanya tepi yang dihaluskan dan dinetralkan dari sisa hijau. Warna sama di luar lubang tidak disentuh.
- Kalau gambar punya warna polos besar DAN sedikit celah transparan, yang dipakai adalah yang luasnya jauh lebih besar.
- Strip 1 sampai 6 foto (satu kolom, dua kolom, grid, strip landscape, lubang berukuran campur, lubang yang menempel ke tepi gambar) terdeteksi. Lubang minimal 0.4% luas gambar.
- Rasio ditebak dari SEMUA lubang; kalau tidak seragam, bingkai berlaku untuk semua rasio.
- Setelah upload, pesan hasil deteksi menyebut warna kunci yang dipakai. Bingkai lama yang masih bermasalah sebaiknya diupload ulang.

## Update v5
- **Atur lubang foto secara manual** (di bawah pratinjau): tentukan jumlah foto 1 sampai 6, susunan 1 atau 2 kolom, bentuk foto, margin, lalu "Susun otomatis". Setiap lubang dapat disesuaikan lewat angka X, Y, Lebar, Tinggi. Area tersebut dilubangi (dijadikan transparan) saat diterapkan, sehingga strip dengan desain apa pun tetap dapat diunggah walaupun deteksi otomatis gagal. Panel terbuka sendiri saat deteksi otomatis tidak berhasil.
- Teks dashboard dirapikan agar lebih profesional.

## Update v6
- **Bingkai video**: di kartu Unggah bingkai, pilih berkas MP4 atau WebM. Beri warna polos (hijau, magenta, cyan, kuning) pada area lubang foto, atau pakai WebM transparan. Tepat 1 lubang. Sudut lubang bisa dibulatkan (kolom "Sudut lubang membulat").
  - Di aplikasi, bingkai diulang otomatis selama video pengguna berjalan (bingkai 10 detik pada video 20 detik = 2 kali).
  - Batas ukuran sekitar 4,2 MB (batas respons Vercel). Berkas yang lebih besar dikecilkan otomatis di browser admin (butuh waktu sepanjang durasi video, jangan tutup halaman). Hasil kompres berformat WebM.
  - Unggahan video dikirim per potongan (maks 3), jadi tidak kena batas 4,5 MB per request. `api/admin.js` sekarang diberi `maxDuration` 60 detik di `vercel.json`.
- **Editor desain bingkai** (kartu "Desain bingkai sendiri"): atur ukuran kanvas, jumlah dan bentuk foto, warna latar (polos, gradasi, pola), garis tepi, sudut membulat, garis sekeliling lubang. Tambah stiker unggahan sendiri (tersimpan di browser admin untuk dipakai lagi), bentuk berwarna, stiker bawaan, dan teks. Geser, cubit/tarik untuk ukuran, putar, gandakan, balik, urutan layer, transparansi, urungkan/ulangi. Lubang foto bisa dipindah lewat tombol "Atur lubang foto". Hasil disimpan sebagai bingkai biasa (foto atau video 1 lubang).

## Update v7
- **Pemilih file menampilkan semua foto dan video** di galeri HP (sebelumnya dibatasi PNG/WebP/GIF/MP4/WebM). Sekarang bisa memilih JPG, PNG, WebP, GIF, dan video apa saja. Foto JPG dipakai dengan lubang warna polos (hijau, magenta, dst.). Video selain MP4/WebM (MOV, MKV, 3GP, dst.) otomatis dikonversi di browser. HEIC tidak bisa dibaca browser: simpan ulang sebagai JPG atau PNG.
- **Bar persen** untuk setiap tahap upload bingkai video: optimasi, unggah per bagian (dengan MB terkirim), dan penyimpanan di server. Unggahan dipecah per sekitar 1 MB dan diulang otomatis sampai 4 kali kalau koneksi putus, jadi tidak macet di "1/2".
- **Optimasi video bingkai** (kotak centang, aktif secara bawaan): 30 fps tetap, keyframe tiap 1 detik, tanpa suara, ukuran maksimal sekitar 3,8 MB. Memakai encoder WebCodecs browser (MP4 H.264, kalau hasilnya terlalu besar otomatis WebM), jadi putarannya di aplikasi mulus. Video dengan transparansi (alpha) tidak dioptimalkan supaya lubang tetap transparan.
- `api/admin.js`: maksimal 6 potongan unggahan (sebelumnya 3).
